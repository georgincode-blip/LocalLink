# Roadmap

This roadmap is a proposed sequence. Items are not marked complete unless implemented in the repository.

## Phase 0 — Validate the problem
- [ ] Interview local retailers and restaurant owners.
- [ ] Interview artisans and community managers.
- [ ] Identify the first geographic area and highest-value categories.
- [ ] Record anonymized findings and revise the problem hypothesis.

**Exit criteria:** a clear initial audience, validated pain points, and a narrow first use case.

## Phase 1 — Prototype and test
- [x] Build a static responsive discovery prototype.
- [x] Add sample categories, search, and filters.
- [ ] Test the prototype with representative users.
- [ ] Improve keyboard navigation and accessibility.
- [ ] Document feedback and product decisions.

**Exit criteria:** users can understand the value proposition and complete the discovery journey in usability tests.

## Phase 2 — Technical foundation
- [ ] Choose a stack based on validated requirements.
- [ ] Define data model and access rules.
- [ ] Add authentication and profile management.
- [ ] Add directory search and filtering.
- [ ] Add automated tests and continuous integration.

**Exit criteria:** a testable development environment with secure access boundaries.

## Phase 3 — Enquiries and trust
- [ ] Add structured service requests.
- [ ] Add enquiry workflow and notifications.
- [ ] Add user reporting and moderation queue.
- [ ] Draft terms, privacy notice, and community rules.
- [ ] Threat-model abuse and spam scenarios.

**Exit criteria:** the core workflow can be tested without relying on manual database changes.

## Phase 4 — Small pilot
- [ ] Recruit a small, opt-in group of local businesses and providers.
- [ ] Provide onboarding and support.
- [ ] Track only necessary, privacy-conscious metrics.
- [ ] Review feedback weekly and prioritize fixes.
- [ ] Publish honest pilot results and known limitations.

**Exit criteria:** evidence on whether the platform produces relevant, useful connections.

## Phase 5 — Improve based on evidence
- [ ] Improve matching based on observed behavior.
- [ ] Evaluate provider verification options.
- [ ] Evaluate sustainable pricing only after user value is demonstrated.
- [ ] Assess operational and legal requirements before broader launch.
