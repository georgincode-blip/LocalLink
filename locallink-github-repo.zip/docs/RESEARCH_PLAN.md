# Research plan

## Objective

Find out whether local businesses and independent service providers have a sufficiently frequent, costly problem finding one another to justify a dedicated local-first platform.

## Recruitment target

Start with a small exploratory sample, for example 5–8 business owners and 5–8 providers. This is a proposed research target, not completed research or a statistically representative sample.

## Interview format

- 15–25 minutes.
- Ask about recent real experiences rather than hypothetical enthusiasm.
- Do not request confidential customer details.
- Ask permission before taking notes or quoting someone.
- Keep notes anonymized and store them securely.

## Business-owner questions

1. Tell me about the last time you needed an artisan or a community manager.
2. How did you search, and what happened?
3. What was frustrating or time-consuming?
4. What information helped you choose a provider?
5. What caused you to reject a provider?
6. How do you currently manage follow-up and trust?
7. What would make a new directory worth trying?

## Provider questions

1. How do new clients currently find you?
2. Which channels produce the best enquiries?
3. What information do you need before deciding to respond?
4. What makes an enquiry irrelevant?
5. How do you show your skills and service area?
6. What would make a local platform useful enough to maintain a profile?

## Prototype test tasks

- Find a provider in a chosen category.
- Narrow results using search or a category filter.
- Explain what information is missing from a profile.
- Describe how you would contact the provider.
- Identify how you would report a suspicious listing.

## Synthesis template

For each observation, record:
- User type (anonymous label only)
- Recent example
- Current workaround
- Pain point
- Frequency / impact
- Evidence strength
- Product implication
- Open question

Separate direct observations from assumptions. Do not present a small exploratory sample as representative of the entire market.
