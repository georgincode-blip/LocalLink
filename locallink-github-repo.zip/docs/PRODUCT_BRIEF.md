# Product brief

## One-sentence description

LocalLink is a local professional discovery platform connecting shops and restaurants with artisans and community managers.

## Problem hypothesis

Local businesses may struggle to find suitable service providers because recommendations, social media, and professional directories are fragmented. Independent providers may struggle to reach businesses that need their services.

This is a hypothesis to test, not a universal claim.

## User groups and needs

### Business owners
- Explain a need without knowing which provider category to search for.
- Find relevant professionals by service and service area.
- Understand what a provider offers before making contact.

### Artisans
- Present services and service areas clearly.
- Receive enquiries that fit their skills and availability.
- Build visibility without relying only on personal networks.

### Community managers
- Explain their offer and areas of expertise.
- Find local businesses that may need help with content and social media.
- Start conversations with clear expectations.

## Core user journey

1. A business owner visits the platform.
2. They search by service or choose a category.
3. They review profiles and service areas.
4. They open a profile and send an enquiry.
5. The provider responds outside the prototype or, in a future product, through a controlled contact workflow.
6. Both sides can report suspicious behavior.

## MVP boundaries

### In scope
- Profile type and service category.
- Public provider profile.
- Search and category filtering.
- Service area.
- Simple project/request brief.
- Contact/enquiry initiation.
- Reporting and moderation workflow.

### Out of scope for first release
- Payments and escrow.
- Complex bidding and quote management.
- AI-based ranking.
- Reviews and reputation scores before a moderation policy exists.
- Native mobile applications.
- Claims of verified status without a real verification process.

## Product risks

- **Cold start:** too few providers in one area can make search feel empty. Start with one locality and a small number of categories.
- **Trust:** false claims and low-quality leads can damage confidence. Provide reporting and clear profile status.
- **Mismatch:** vague requests create wasted time. Use structured fields and category-specific prompts.
- **Privacy:** business contact details may be personal data. Minimize collection and define retention.
- **Marketplace imbalance:** demand and supply may grow at different speeds. Interview both sides and measure successful connections, not just sign-ups.

## Validation questions

1. How do you currently find an artisan or community manager?
2. What makes you trust a provider?
3. How long does it typically take to find someone suitable?
4. What information do you need before contacting a provider?
5. What would make you return to a platform like this?
6. For providers: what makes an enquiry valuable or a waste of time?

## Definition of MVP success

Before setting numeric targets, establish a baseline through interviews and usability tests. Then measure task completion, time-to-find, enquiry relevance, response rate, and satisfaction.
