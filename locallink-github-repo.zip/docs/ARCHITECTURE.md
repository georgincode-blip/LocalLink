# Architecture notes

## Current state

The repository currently contains a static browser prototype:

- `prototype/index.html` — page structure and sample data.
- `prototype/styles.css` — responsive visual design.
- `prototype/app.js` — client-side search, filters, and demo interactions.

There is no server, database, authentication, analytics, or external service integration.

## Potential future architecture

The following is a direction to evaluate after user research, not an implemented system.

- **Web client:** accessible responsive interface.
- **Application API:** profile, search, request, and report endpoints.
- **Relational database:** users, professional profiles, categories, service areas, requests, and reports.
- **Authentication:** secure session handling and role-aware authorization.
- **Notifications:** opt-in transactional notifications.
- **Moderation:** report queue, audit trail, and defined escalation process.

## Candidate data entities

- `User`: account identity and authentication metadata.
- `ProfessionalProfile`: public description, role, service categories, and service area.
- `ServiceCategory`: controlled category list.
- `ServiceRequest`: business need, category, location area, and status.
- `Enquiry`: request-to-provider contact attempt and status.
- `Report`: reported profile or request, reason, status, and moderator action.

## Security and privacy questions to answer before launch

- Which fields are public and which are private?
- How can a user edit or delete their data?
- How long are requests and reports retained?
- How are spam, harassment, impersonation, and fraudulent listings handled?
- Which actions require authorization checks on the server?
- How are secrets managed outside source control?
- What backup and incident-response process is appropriate?

## Engineering principles

- Validate inputs on the server once a backend exists.
- Enforce authorization on the server, not only in the UI.
- Avoid collecting sensitive information without a clear need.
- Never commit API keys, credentials, or real user data.
- Add tests for access control and abuse cases before launch.
- Keep sample data clearly marked as fictional.
