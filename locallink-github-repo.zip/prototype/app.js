const searchInput = document.querySelector("#search");
const filterButtons = [...document.querySelectorAll(".filter")];
const cards = [...document.querySelectorAll(".profile-card")];
const emptyState = document.querySelector("#empty-state");
let activeFilter = "All";

function updateDirectory() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  cards.forEach((card) => {
    const matchesCategory = activeFilter === "All" || card.dataset.category === activeFilter;
    const matchesSearch = card.dataset.search.includes(query);
    const show = matchesCategory && matchesSearch;
    card.hidden = !show;
    if (show) visible += 1;
  });
  emptyState.hidden = visible !== 0;
}

searchInput.addEventListener("input", updateDirectory);
filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach((item) => {
      const isActive = item === button;
      item.classList.toggle("active", isActive);
      item.setAttribute("aria-pressed", String(isActive));
    });
    updateDirectory();
  });
});

const dialog = document.querySelector("#profile-dialog");
const dialogTitle = document.querySelector("#dialog-title");
document.querySelectorAll(".profile-link").forEach((button) => {
  button.addEventListener("click", () => {
    dialogTitle.textContent = button.dataset.name;
    if (typeof dialog.showModal === "function") dialog.showModal();
    else window.alert(`${button.dataset.name}: fictional demo profile.`);
  });
});
document.querySelector(".dialog-close").addEventListener("click", () => dialog.close());
document.querySelector("#dialog-ok").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});
