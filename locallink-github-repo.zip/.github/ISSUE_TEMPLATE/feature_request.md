---
name: Feature request
about: Suggest a user-centered improvement
title: "[Feature] "
labels: enhancement
assignees: ""
---

## User problem
Who experiences this problem, and in what situation?

## Proposed outcome
What should become easier or better?

## Why this matters
What evidence supports the need? Mark assumptions clearly.

## Acceptance criteria
- [ ]
- [ ]
