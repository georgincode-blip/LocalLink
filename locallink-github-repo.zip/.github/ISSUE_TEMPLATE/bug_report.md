---
name: Bug report
about: Report a reproducible problem in the prototype
title: "[Bug] "
labels: bug
assignees: ""
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Browser and device

## Additional context
Do not include personal data or secrets.
